import { useEffect, useState } from "react";
import { PERAN } from "@smart-locker/shared";
import { ambilStatusBackend } from "./lib/api.js";

// Kerangka Tahap 2. Halaman ini hanya memeriksa koneksi ke backend.
// Sidebar, login, dan dashboard dibangun di tahap berikutnya.
export default function App() {
  const [keadaan, setKeadaan] = useState({ tahap: "memuat" });

  useEffect(() => {
    ambilStatusBackend()
      .then(({ status, data }) => setKeadaan({ tahap: status === 200 ? "ok" : "gagal", data }))
      .catch(() => setKeadaan({ tahap: "tidak_terjangkau" }));
  }, []);

  return (
    <main className="halaman">
      <h1>Aplikasi {PERAN.ADMIN}</h1>
      <p className="sub">Kerangka aplikasi Admin Smart Locker</p>
      <section className="kartu">
        <h2>Status backend</h2>
        {keadaan.tahap === "memuat" && <p>Memeriksa koneksi...</p>}
        {keadaan.tahap === "ok" && <p className="ok">Terhubung. Database: {keadaan.data.database}</p>}
        {keadaan.tahap === "gagal" && <p className="gagal">Backend terhubung, tetapi database belum siap.</p>}
        {keadaan.tahap === "tidak_terjangkau" && (
          <p className="gagal">Tidak dapat menghubungi backend. Pastikan server sudah berjalan.</p>
        )}
      </section>
    </main>
  );
}
