// Konstanta yang dipakai bersama oleh backend dan kedua aplikasi frontend.
// Nilai di sini mengikuti keputusan pada dokumen Tahap 1.

export const PERAN = Object.freeze({
  ADMIN: "admin",
  KONSUMEN: "konsumen",
  PERANGKAT: "perangkat",
});

export const STATUS_AKUN = Object.freeze({
  MENUNGGU_VERIFIKASI: "menunggu_verifikasi",
  TERVERIFIKASI: "terverifikasi",
  DITOLAK: "ditolak",
  NONAKTIF: "nonaktif",
});

export const HASIL_AKSES = Object.freeze({
  BERHASIL: "berhasil",
  GAGAL_KTP: "gagal_ktp",
  GAGAL_PIN: "gagal_pin",
  TANPA_AKSES: "tanpa_akses",
  TERKUNCI: "terkunci",
});

export const ATURAN = Object.freeze({
  MASA_AKSES_HARI_DEFAULT: 30,
  PIN_MAKS_SALAH: 3,
  PIN_KUNCI_MENIT: 5,
  OTORISASI_BUKA_DETIK: 10,
  PANJANG_PIN: 6,
  PANJANG_NIK: 16,
});
