# Tahap 1: Desain UI/UX dan Alur Sistem Smart Locker

Dokumen ini menjadi acuan untuk Tahap 2 (struktur proyek) dan seterusnya.

## 1. Keputusan teknologi

| Aspek | Keputusan |
|---|---|
| OCR | Tesseract OCR di backend (Docker, bahasa `eng`; tambah `ind` bila perlu) |
| Frontend | React.js + Vite, dua aplikasi (Admin dan Konsumen) |
| Backend | Node.js + Express.js, REST API, satu layanan untuk kedua aplikasi |
| Database | PostgreSQL |
| Hosting | Railway: paket Trial untuk pengembangan, paket Hobby ($5/bulan) setelah kebutuhan sumber daya diketahui |
| Foto KTP | Dihapus segera setelah OCR dan pencocokan NIK selesai, termasuk jika proses gagal |

## 2. Peran dan hak akses

| Kemampuan | Admin | Konsumen | Perangkat (ESP32) |
|---|---|---|---|
| Login | Email + password (tabel `admins`) | Email + password (tabel `users`) | Kunci perangkat unik |
| Lihat data semua pengguna | Ya | Tidak | Tidak |
| Lihat data diri sendiri | Ya | Ya | Tidak |
| Ubah data pengguna | Ya | Hanya data diri sendiri (nama, HP) | Tidak |
| Verifikasi KTP/NIK | Ya | Tidak | Tidak (hanya mengirim gambar) |
| Reset PIN | Ya | Ubah PIN sendiri | Tidak |
| Berikan hak akses locker | Ya | Tidak | Tidak |
| Buka locker | Tidak melalui web | Tidak melalui web | Ya, hanya dengan otorisasi valid |
| Lihat riwayat | Semua | Miliknya sendiri | Mengirim log |

Aturan yang wajib dijaga di backend:
- Konsumen tidak bisa mendaftar sebagai admin.
- Endpoint `/api/admin/*` hanya menerima sesi dengan peran admin.
- Endpoint `/api/konsumen/*` selalu memakai `user_id` dari sesi, bukan dari parameter.
- Endpoint `/api/perangkat/*` hanya menerima perangkat yang terdaftar dan memiliki kunci perangkat.

## 3. Daftar layar Admin

Admin memakai sidebar biru dengan area kerja putih. Setiap halaman memiliki kartu ringkasan, bilah pencarian, dan tabel.

| No | Layar | Isi utama |
|---|---|---|
| A1 | Login | Email, password, pesan gagal umum (tanpa membedakan email dan password salah) |
| A2 | Dashboard | Kartu: total pengguna, locker tersedia, locker terpakai, akses berhasil, akses ditolak. Grafik akses 7 hari. Aktivitas terbaru. |
| A3 | Data konsumen | Tabel dengan pencarian, filter status verifikasi dan status akun, tombol tambah dan ekspor |
| A4 | Detail konsumen | Data diri, status verifikasi KTP (NIK tampil sebagian), status akun aktif atau nonaktif, daftar hak akses, riwayat singkat |
| A5 | Verifikasi KTP | Antrean pendaftar baru. Admin melihat hasil OCR yang sudah dicocokkan (NIK disamarkan) dan menyetujui atau menolak. |
| A6 | Reset PIN | Tombol reset yang membuat PIN sementara (PIN ditampilkan sekali dan tidak bisa dilihat lagi) |
| A7 | Manajemen locker | Tabel locker: nomor, lokasi, status, perangkat terhubung, status koneksi terakhir |
| A8 | Hak akses | Memberikan atau mencabut hak akses konsumen ke locker tertentu, dengan masa berlaku |
| A9 | Riwayat aktivitas | Tabel akses dengan filter tanggal, pengguna, locker, dan status. Kolom: waktu, pengguna, locker, status KTP, status PIN, hasil akhir, keterangan gagal. |

Catatan: kolom "Activity Status" dari referensi gambar pertama dipakai untuk status koneksi perangkat ("terhubung 2 menit lalu", "tidak terhubung 3 hari lalu").

## 4. Daftar layar Konsumen

Konsumen memakai navigasi atas di desktop dan navigasi bawah di ponsel. Tidak ada sidebar.

| No | Layar | Isi utama |
|---|---|---|
| K1 | Registrasi | Nama lengkap, email, nomor HP, NIK, password, persetujuan pemrosesan data pribadi (dijelaskan sebelum data dikirim) |
| K2 | Login | Email dan password |
| K3 | Beranda | Status identitas (menunggu, terverifikasi, ditolak), status hak akses, ringkasan locker |
| K4 | Informasi locker | Hanya locker yang diberikan admin: nomor, lokasi, masa berlaku akses, status perangkat |
| K5 | Pengaturan PIN | Buat PIN baru, ubah PIN (perlu PIN lama), konfirmasi, validasi 6 digit |
| K6 | Riwayat penggunaan | Tabel akses milik sendiri dengan filter tanggal dan status |
| K7 | Profil | Ubah nama dan nomor HP, ubah password |

Tidak ada tombol "buka locker" di web. Konsumen diberi tahu bahwa pembukaan dilakukan di depan locker dengan KTP dan PIN.

## 5. Status akun dan alur registrasi

Status akun konsumen:

```
baru daftar → menunggu verifikasi → terverifikasi → (diberi hak akses)
                     ↓
                  ditolak
```

Keputusan yang sudah disetujui:
- Registrasi konsumen masuk status "menunggu verifikasi", bukan langsung aktif.
- Admin memverifikasi NIK dari hasil OCR di layar A5. Hanya akun "terverifikasi" yang bisa menerima hak akses.
- Hak akses diberikan admin di layar A8 dengan masa berlaku default 30 hari. Admin dapat mengatur tanggal mulai dan tanggal berakhir secara manual.
- Satu konsumen boleh memiliki akses ke beberapa locker. Setiap locker diberikan secara terpisah oleh admin.
- Akun admin pertama dibuat lewat seed database. Tidak ada halaman registrasi admin publik. Admin yang sudah ada dapat membuat akun admin lain.

Alur pendaftaran lengkap:
1. Konsumen mengisi K1 dan menyetujui pemrosesan data.
2. Konsumen mengunggah atau mengambil foto KTP. Foto dikirim ke backend (tidak disimpan).
3. Backend menjalankan Tesseract, mengekstrak NIK, lalu memeriksa format 16 digit.
4. Backend menyimpan hash NIK dan status "menunggu verifikasi". Foto dihapus.
5. Admin membuka A5, membandingkan data, lalu menyetujui atau menolak.

Jika OCR gagal, konsumen diminta mengambil ulang foto. Foto yang gagal diproses juga langsung dihapus.

## 6. Alur autentikasi perangkat

Perangkat yang terlibat: ESP32-CAM (kamera), ESP32 utama (keypad dan solenoid).

```
1. ESP32-CAM mengambil gambar KTP
2. ESP32-CAM → backend: POST /api/perangkat/ktp-gambar   (gambar, kunci perangkat)
3. Backend: OCR → NIK → cocokkan dengan database → hapus gambar
4. Backend → ESP32-CAM: hasil (valid / tidak terbaca / tidak terdaftar / tanpa akses)
   - Jika valid: backend membuat sesi autentikasi (berlaku 60 detik, satu kali)
5. ESP32 utama menampilkan "Masukkan PIN"
6. Keypad → ESP32 utama → backend: POST /api/perangkat/verifikasi-pin  (ID sesi, PIN, kunci perangkat)
7. Backend: cek PIN dengan hash Argon2id atau bcrypt
   - Salah: hitung percobaan per sesi autentikasi. Setelah 3 kali, sesi tersebut dikunci 5 menit. Locker dan pengguna lain tidak ikut terkunci.
   - Benar: buat perintah buka yang berisi ID perintah (nonce), ID perangkat, ID locker, dan waktu kedaluwarsa 10 detik. Perintah ditandatangani backend.
8. ESP32 utama menerima perintah buka → mengaktifkan solenoid 5 detik
9. ESP32 utama → backend: konfirmasi selesai (nonce dipakai, perintah ditandai selesai)
10. Backend mencatat hasil akhir di access_logs
```

Aturan keamanan:
- PIN dikirim lewat HTTPS. Firmware tidak menghitung hash PIN sendiri, dan tidak menyimpan garam rahasia.
- Sertifikat TLS diverifikasi dengan sertifikat CA yang dipasang di firmware.
- Perintah buka hanya berlaku satu kali dan sudah kedaluwarsa setelah 10 detik.
- Jika koneksi terputus, solenoid tetap terkunci (kondisi default).
- ESP32 hanya membuka locker jika menerima perintah yang ditandatangani backend dan belum kedaluwarsa.
- Perintah ditandatangani dengan HMAC-SHA256 menggunakan kunci rahasia server. ESP32 utama memverifikasi tanda tangan sebelum mengaktifkan solenoid.
- Perintah ditolak jika tanda tangan tidak valid, ID perangkat atau locker tidak cocok, sudah kedaluwarsa, atau ID-nya sudah pernah dipakai.

## 7. Status dan pesan di layar

| Kondisi | Tampilan di web | Tampilan di ESP32 |
|---|---|---|
| Memuat data | Skeleton loading | Ikon sibuk |
| Data kosong | "Belum ada pengguna. Tambahkan pengguna pertama." | - |
| KTP tidak terbaca | "KTP tidak terbaca. Ambil ulang foto dengan pencahayaan cukup." | "KTP tidak terbaca" |
| NIK tidak terdaftar | "NIK belum terdaftar." | "KTP tidak terdaftar" |
| Tanpa hak akses | "Anda belum memiliki akses ke loker ini." | "Tidak ada akses" |
| PIN salah | "PIN salah. Sisa percobaan: 2." | "PIN salah, sisa 2" |
| Terkunci | "Akses dikunci 5 menit karena terlalu banyak percobaan." | "Terkunci 5 menit" |
| Server tidak dapat dijangkau | "Tidak dapat terhubung ke server. Coba lagi." | "Tidak terhubung, locker tetap terkunci" |
| Berhasil | "Akses berhasil." | "Pintu terbuka" |

Seluruh antarmuka memakai bahasa Indonesia.

## 8. Kebijakan data KTP dan NIK

- Foto KTP tidak disimpan di database maupun di penyimpanan permanen.
- Foto disimpan sementara di memori selama OCR berjalan, lalu dihapus. Penghapusan juga terjadi jika OCR gagal atau terjadi error.
- Yang disimpan adalah HMAC-SHA256 dari NIK dengan kunci rahasia server, bukan hash biasa. Dengan cara ini pencocokan tetap konsisten, dan NIK tidak bisa ditebak dari daftar kemungkinan.
- Kolom NIK tersamarkan (misalnya `************1234`) disimpan terpisah untuk tampilan admin.
- Kunci HMAC disimpan sebagai environment variable di Railway, bukan di dalam kode.
- Admin tidak bisa melihat NIK lengkap. Tampilan hanya menunjukkan sebagian.
- Log tidak boleh memuat NIK lengkap, PIN, atau token.
- Konsumen menyetujui pemrosesan data sebelum pendaftaran (K1). Persetujuan dicatat dengan waktu.

## 9. Catatan Railway dan biaya

- Paket Trial dipakai untuk pengembangan dan pengujian awal. Batas kredit dan batas sumber daya Trial perlu diperiksa di dashboard Railway.
- Setelah kebutuhan diketahui, paket Hobby dipertimbangkan. Harga dasar yang Anda sebutkan adalah $5 per bulan. Cek kembali di halaman harga Railway karena biaya pemakaian tambahan bisa berubah.
- Pemantauan yang perlu dilakukan sebelum deployment final: pemakaian CPU dan RAM saat OCR berjalan (Tesseract cukup berat untuk gambar besar), penyimpanan database, dan jumlah permintaan dari perangkat.
- OCR dijalankan di container yang memuat Tesseract. Gambar dikecilkan dan diubah ke skala abu-abu sebelum diproses untuk mempercepat dan meningkatkan akurasi.

## 10. Kriteria selesai Tahap 1

Tahap 1 dianggap selesai jika:
- Peta layar Admin dan Konsumen (sebagian 3 dan 4) disetujui.
- Alur registrasi dan status akun (bagian 5) disetujui.
- Alur autentikasi perangkat (bagian 6) disetujui.
- Pesan kesalahan (bagian 7) disetujui.
- Kebijakan data KTP (bagian 8) disetujui.

## 11. Keputusan final (disetujui)

| Pertanyaan | Keputusan |
|---|---|
| Verifikasi admin sebelum hak akses | Wajib |
| Masa berlaku hak akses default | 30 hari, dapat diatur admin |
| Satu konsumen, beberapa locker | Boleh, izin diberikan per locker |
| Pembuatan akun admin pertama | Seed database |
| Batas kesalahan PIN | 3 kali, sesi autentikasi dikunci 5 menit |
| Masa berlaku perintah buka | 10 detik, sekali pakai, ditandatangani backend |

Dokumen ini menjadi acuan pengembangan Smart Locker mulai Tahap 2.
