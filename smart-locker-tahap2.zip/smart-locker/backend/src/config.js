// Membaca dan memvalidasi konfigurasi dari environment variable.
// Semua kredensial diambil dari environment, tidak ditulis di dalam kode.

export function muatKonfigurasi(env = process.env) {
  const wajib = ["DATABASE_URL"];
  const kurang = wajib.filter((nama) => !env[nama]);
  if (kurang.length > 0) {
    throw new Error("Variabel environment belum diisi: " + kurang.join(", "));
  }

  const originDefault = "http://localhost:5173,http://localhost:5174";

  return Object.freeze({
    env: env.NODE_ENV || "development",
    port: Number(env.PORT || 3000),
    databaseUrl: env.DATABASE_URL,
    dbSsl: env.DB_SSL === "true",
    corsOrigins: (env.CORS_ORIGINS || originDefault)
      .split(",")
      .map((asal) => asal.trim())
      .filter(Boolean),
  });
}
