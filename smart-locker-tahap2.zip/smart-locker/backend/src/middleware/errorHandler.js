// Penanganan error terpusat. Pesan error ke klien tidak memuat detail internal,
// dan isi body permintaan tidak pernah dicatat ke log.

export function tanganiRuteTidakAda(_req, res) {
  res.status(404).json({ ok: false, pesan: "Rute tidak ditemukan" });
}

export function penangananError(err, _req, res, next) {
  console.error("Kesalahan:", err.message);
  if (res.headersSent) return next(err);

  if (err.type === "entity.parse.failed") {
    return res.status(400).json({ ok: false, pesan: "Format JSON tidak valid" });
  }
  if (err.type === "entity.too.large") {
    return res.status(413).json({ ok: false, pesan: "Data terlalu besar" });
  }
  res.status(500).json({ ok: false, pesan: "Terjadi kesalahan pada server" });
}
