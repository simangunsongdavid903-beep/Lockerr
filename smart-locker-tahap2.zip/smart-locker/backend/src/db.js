import pg from "pg";

let pool = null;

export function buatPool({ databaseUrl, dbSsl }) {
  pool = new pg.Pool({
    connectionString: databaseUrl,
    max: 5,
    idleTimeoutMillis: 30000,
    connectionTimeoutMillis: 5000,
    ssl: dbSsl ? { rejectUnauthorized: false } : false,
  });
  pool.on("error", (err) => {
    console.error("Kesalahan pada koneksi PostgreSQL:", err.message);
  });
  return pool;
}

export function getPool() {
  if (!pool) throw new Error("Pool database belum dibuat");
  return pool;
}

// Memeriksa koneksi database dengan batas waktu 3 detik.
export async function cekDatabase() {
  const kueri = getPool().query("SELECT 1");
  const batas = new Promise((_, tolak) =>
    setTimeout(() => tolak(new Error("Batas waktu habis")), 3000)
  );
  try {
    await Promise.race([kueri, batas]);
    return true;
  } catch {
    return false;
  }
}
