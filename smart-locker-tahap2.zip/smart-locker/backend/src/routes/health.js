import { Router } from "express";
import { cekDatabase } from "../db.js";

const waktuMulai = Date.now();

export function buatRouterHealth() {
  const router = Router();

  router.get("/health", async (_req, res) => {
    const dbOk = await cekDatabase();
    res.status(dbOk ? 200 : 503).json({
      ok: dbOk,
      layanan: "smart-locker-backend",
      uptimeDetik: Math.round((Date.now() - waktuMulai) / 1000),
      database: dbOk ? "terhubung" : "tidak terhubung",
    });
  });

  return router;
}
