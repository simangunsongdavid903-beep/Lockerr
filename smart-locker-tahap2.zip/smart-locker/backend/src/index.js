import express from "express";
import helmet from "helmet";
import cors from "cors";
import { muatKonfigurasi } from "./config.js";
import { buatPool } from "./db.js";
import { buatRouterHealth } from "./routes/health.js";
import { penangananError, tanganiRuteTidakAda } from "./middleware/errorHandler.js";

const cfg = muatKonfigurasi();
buatPool(cfg);

const app = express();
app.disable("x-powered-by");
app.use(helmet());
app.use(cors({ origin: cfg.corsOrigins, credentials: true }));
app.use(express.json({ limit: "64kb" }));

app.use("/api", buatRouterHealth());

app.use(tanganiRuteTidakAda);
app.use(penangananError);

const server = app.listen(cfg.port, () => {
  console.log(`Backend berjalan di port ${cfg.port} (${cfg.env})`);
});

function matikan() {
  server.close(() => process.exit(0));
}
process.on("SIGTERM", matikan);
process.on("SIGINT", matikan);
