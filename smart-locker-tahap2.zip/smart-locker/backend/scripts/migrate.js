// Menjalankan migrasi SQL dari folder database/migrations secara berurutan.
// Setiap file hanya dijalankan sekali, dicatat di tabel schema_migrations.
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import "dotenv/config";
import pg from "pg";

const folder = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "../../database/migrations");

const databaseUrl = process.env.DATABASE_URL;
if (!databaseUrl) {
  console.error("DATABASE_URL belum diisi");
  process.exit(1);
}

const pool = new pg.Pool({
  connectionString: databaseUrl,
  ssl: process.env.DB_SSL === "true" ? { rejectUnauthorized: false } : false,
});

async function main() {
  const client = await pool.connect();
  try {
    await client.query(`
      CREATE TABLE IF NOT EXISTS schema_migrations (
        nama TEXT PRIMARY KEY,
        dijalankan_pada TIMESTAMPTZ NOT NULL DEFAULT NOW()
      )
    `);

    const sudah = new Set(
      (await client.query("SELECT nama FROM schema_migrations")).rows.map((r) => r.nama)
    );

    const berkas = fs.existsSync(folder)
      ? fs.readdirSync(folder).filter((f) => f.endsWith(".sql")).sort()
      : [];

    if (berkas.length === 0) {
      console.log("Belum ada file migrasi.");
      return;
    }

    for (const nama of berkas) {
      if (sudah.has(nama)) continue;
      const sql = fs.readFileSync(path.join(folder, nama), "utf8");
      await client.query("BEGIN");
      try {
        await client.query(sql);
        await client.query("INSERT INTO schema_migrations (nama) VALUES ($1)", [nama]);
        await client.query("COMMIT");
        console.log("Migrasi dijalankan:", nama);
      } catch (err) {
        await client.query("ROLLBACK");
        throw new Error(`Gagal pada ${nama}: ${err.message}`);
      }
    }
    console.log("Migrasi selesai.");
  } finally {
    client.release();
    await pool.end();
  }
}

main().catch((err) => {
  console.error(err.message);
  process.exit(1);
});
