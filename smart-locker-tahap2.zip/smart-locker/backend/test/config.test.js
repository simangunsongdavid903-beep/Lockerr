import test from "node:test";
import assert from "node:assert/strict";
import { muatKonfigurasi } from "../src/config.js";

test("melempar error jika DATABASE_URL belum diisi", () => {
  assert.throws(() => muatKonfigurasi({}), /DATABASE_URL/);
});

test("memakai nilai default ketika variabel opsional kosong", () => {
  const cfg = muatKonfigurasi({ DATABASE_URL: "postgres://contoh" });
  assert.equal(cfg.port, 3000);
  assert.equal(cfg.dbSsl, false);
  assert.deepEqual(cfg.corsOrigins, ["http://localhost:5173", "http://localhost:5174"]);
});

test("membaca CORS_ORIGINS dan DB_SSL dari environment", () => {
  const cfg = muatKonfigurasi({
    DATABASE_URL: "postgres://contoh",
    DB_SSL: "true",
    CORS_ORIGINS: "https://admin.contoh.id, https://konsumen.contoh.id",
  });
  assert.equal(cfg.dbSsl, true);
  assert.deepEqual(cfg.corsOrigins, ["https://admin.contoh.id", "https://konsumen.contoh.id"]);
});
